import React from "react";
import Box from "@mui/material/Box";
const QuestionCode = () => {
  return <Box><img src="/img/codeex.png" component="form" noValidate xs sx={{ mt: 1, alignItems: "center" }} /></Box>;
};

export default QuestionCode;
