import React from 'react'

const PointStatement = () => {
  return (
    <div>PointStatement</div>
  )
}

export default PointStatement