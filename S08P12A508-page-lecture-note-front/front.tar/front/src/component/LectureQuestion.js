import React from 'react'

const LectureQuestion = () => {
  return (
    <div>LectureQuestion</div>
  )
}

export default LectureQuestion