import React from 'react'

const PointRequestSuccess = () => {
  return (
    <div>PointRequestSuccess</div>
  )
}

export default PointRequestSuccess