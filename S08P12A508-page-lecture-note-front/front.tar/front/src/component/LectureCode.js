import React from 'react'

const LectureCode = () => {
  return (
    <div>LectureCode</div>
  )
}

export default LectureCode