import React from 'react'

const QuestionAbout = () => {
  return (
    <div><img src="/img/problemex.png"  component="form" noValidate xs sx={{ mt: 1, alignItems: "center" }}/></div>
  )
}

export default QuestionAbout