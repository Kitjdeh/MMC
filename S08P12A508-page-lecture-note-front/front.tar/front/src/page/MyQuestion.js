import React from 'react'

const MyQuestion = () => {
  return (
    <div>MyQuestion</div>
  )
}

export default MyQuestion