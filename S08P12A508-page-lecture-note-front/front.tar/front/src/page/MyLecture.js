import React from 'react'

const MyLecture = () => {
  return (
    <div>MyLecture</div>
  )
}

export default MyLecture