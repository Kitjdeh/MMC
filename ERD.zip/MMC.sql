-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema mmc
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mmc
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mmc` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `mmc` ;

-- -----------------------------------------------------
-- Table `mmc`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`user` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `is_manager` INT NULL DEFAULT '0',
  `is_kakao` INT NULL DEFAULT '0',
  `is_online` INT NULL DEFAULT '0',
  `profile_image` VARCHAR(1000) NULL DEFAULT NULL,
  `identity` VARCHAR(20) NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  `name` VARCHAR(20) NOT NULL,
  `email` VARCHAR(50) NOT NULL,
  `nickname` VARCHAR(20) NOT NULL,
  `language` INT NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `academic_ability` VARCHAR(20) NULL DEFAULT NULL,
  `workplace` VARCHAR(20) NULL DEFAULT NULL,
  `baekjoon_id` VARCHAR(50) NULL DEFAULT NULL,
  `award` VARCHAR(100) NULL DEFAULT NULL,
  `point` INT NULL DEFAULT '0',
  `temperature` INT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE INDEX `identity_UNIQUE` (`identity` ASC),
  UNIQUE INDEX `password_UNIQUE` (`password` ASC),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  UNIQUE INDEX `nickname_UNIQUE` (`nickname` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `mmc`.`board`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`board` (
  `board_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `title` VARCHAR(50) NOT NULL,
  `content` VARCHAR(1000) NOT NULL,
  `date` TIMESTAMP NULL DEFAULT NULL,
  `type` INT NULL DEFAULT '0',
  PRIMARY KEY (`board_id`),
  INDEX `fk_board_user1_idx` (`user_id` ASC),
  CONSTRAINT `fk_board_user1`
    FOREIGN KEY (`user_id`)
    REFERENCES `mmc`.`user` (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `mmc`.`question`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`question` (
  `question_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `progress` INT NOT NULL,
  `progress_score` INT NULL DEFAULT NULL,
  `language` INT NOT NULL,
  `category` TINYINT NOT NULL,
  `algorithm` INT NOT NULL,
  `source` INT NOT NULL,
  `question_number` INT NOT NULL,
  `title` VARCHAR(50) NOT NULL,
  `content` VARCHAR(1000) NOT NULL,
  `reservation` TIMESTAMP NOT NULL,
  `code` VARCHAR(10000) NOT NULL,
  `point` INT NOT NULL,
  PRIMARY KEY (`question_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `mmc`.`lecture_note`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`lecture_note` (
  `lecture_note_id` INT NOT NULL AUTO_INCREMENT,
  `question_id` INT NOT NULL,
  `lecture_time` INT NULL DEFAULT '0',
  `pdf_url` VARCHAR(200) NULL,
  `image_url` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`lecture_note_id`),
  INDEX `fk_lecture_note_question1_idx` (`question_id` ASC),
  CONSTRAINT `fk_lecture_note_question1`
    FOREIGN KEY (`question_id`)
    REFERENCES `mmc`.`question` (`question_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `mmc`.`question_trainer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`question_trainer` (
  `question_trainer_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `question_id` INT NOT NULL,
  `is_adopt` INT NULL DEFAULT '0',
  PRIMARY KEY (`question_trainer_id`),
  INDEX `fk_question_trainer_user1_idx` (`user_id` ASC),
  INDEX `fk_question_trainer_question1_idx` (`question_id` ASC),
  CONSTRAINT `fk_question_trainer_question1`
    FOREIGN KEY (`question_id`)
    REFERENCES `mmc`.`question` (`question_id`),
  CONSTRAINT `fk_question_trainer_user1`
    FOREIGN KEY (`user_id`)
    REFERENCES `mmc`.`user` (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `mmc`.`trade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mmc`.`trade` (
  `trade_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `deposit_and_withdrawal` INT NOT NULL,
  `amount` INT NOT NULL,
  `date` TIMESTAMP NOT NULL,
  `bank` VARCHAR(20) NOT NULL,
  `account` VARCHAR(50) NOT NULL,
  `process` TINYINT NULL DEFAULT 0,
  PRIMARY KEY (`trade_id`),
  INDEX `fk_trade_list_user_idx` (`user_id` ASC),
  CONSTRAINT `fk_trade_list_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `mmc`.`user` (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
