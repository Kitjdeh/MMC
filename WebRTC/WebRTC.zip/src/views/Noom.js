// import React from "react";

// const Noom = () => {
//   return (
//     <>
//       <meta charSet="UTF-8" />
//       <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
//       <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//       <title>Noom</title>
//       <link rel="stylesheet" href="https://unpkg.com/mvp.css" />
    
//       <header>
//         <h1>Noom</h1>
//       </header>

//       <main>
//         <div id="welcome">
//           <form action="">
//             <input type="text" placeholder="room name" />
//             <button>Enter room</button>
//           </form>
//         </div>
//         <div id="call">
//           <div id="myStream">
//             <video id="myFace" autoPlay playsInline width="1200px" height="800px"></video>
//             <button id="mute">Mute</button>
//             <button id="camera">Turn Camera Off</button>
//             <button id="shareScreen">Share Screen</button>
//             <select id="cameras"></select>
//             <video id="testVideo" autoPlay playsInline></video>
//             <video id="peersFace" autoPlay playsInline></video>
//           </div>
//         </div>
//       </main>

//       <script src="/socket.io/socket.io.js"></script>
//       <script src="/public/js/app.js"></script>
//     </>
//   );
// };

// export default Noom;
